﻿using System.Windows.Forms;

namespace Timer
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(true);
            Application.Run(new Timer());
        }
    }
}