using System;
using System.Threading;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace Timer
{
    public class Timer : Form
    {
        Thread consoleTimer = new Thread(ConsoleWrite);
        Thread formTimer = new Thread(FormWriter);
        Thread start = new Thread(new ThreadStart(Timer.startTimerThread));

        static Label labelTime = new Label();
        static Label labelTimer = new Label();
        Button _started = new Button();
        Button _stoped = new Button();
        public static long startTime;
        public static long endTime;
        public static long yourTime;
        public static bool resetTime = false;
        public static bool RunStartThread = false;
        public static int FirstHour = 0;
        public static int FirstMinute = 0;
        public static int FirstSecond = 0;
        public int SecondHour = 0;
        public int SecondMinute = 0;
        public int SecondSecond = 0;
        public int FinalTime = 0;
        public int FinalMinute = 0;
        public int FinalSecond = 0;
        public static bool loadTime = false;
        public static bool StartRun = false;
        public static bool restartTime = false;

        public Timer()
        {
            
            InicializaceMetod();
        }

        public void InicializaceMetod()
        {
            
            
            SetParamertsComponent();

            AddingComponents();

            consoleTimer.Start();

            formTimer.Start();

            ComponentSetFunction();
        }

        private void ComponentSetFunction()
        {
            _started.Click += new EventHandler(Start);
            _stoped.Click += new EventHandler(Stop);
        }

        private void Stop(object sender, EventArgs e)
        {
            if (FirstHour != 0 && FirstMinute != 0 && FirstSecond != 0)
            {
                loadTime = false;
                resetTime = true;
                restartTime = false;
                DateTime now = DateTime.Now;
                SecondHour = now.Hour;
                SecondMinute = now.Minute;
                SecondSecond = now.Second;
                int firsttime = 0;
                int secondtime = 0;
                int hour = 0;
                int minutes = 0;
                int seconds = 0;

                firsttime = (FirstHour * (2 * 60)) + (FirstMinute * 60) + FirstSecond;
                secondtime = (SecondHour * (2 * 60)) + (SecondMinute * 60) + SecondSecond;
                FinalTime = secondtime - firsttime;
                hour = FinalTime / 3600;
                minutes = FinalTime / 60;
                if (FinalTime > 60)
                {
                    while (FinalTime > 59)
                    {
                        FinalTime = FinalTime - 60;
                    }

                    seconds = FinalTime;
                }
                else
                {
                    seconds = FinalTime;
                }

                labelTimer.Text = ("Timer " + hour + ":" + minutes + ":" + seconds);
                FirstHour = 0;
                FirstMinute = 0;
                FirstSecond = 0;
                SecondHour = 0;
                SecondMinute = 0;
                SecondSecond = 0;
            }
        }

        private void Start(object sender, EventArgs e)
        {
            DateTime now = DateTime.Now;
            if (loadTime == false)
            {
                FirstHour = now.Hour;
                FirstMinute = now.Minute;
                FirstSecond = now.Second;
                loadTime = true;
            }
            if (StartRun == false)
            {
                
                
                start.Start();
                StartRun = true;
            }
            else if (StartRun)
            {
                restartTime = true;
            }
        }

        public static void startTimerThread()
        {
            int hour = 0;
            int minutes = 0;
            int seconds = 0;
            DateTime now = DateTime.Now;
            FirstHour = now.Hour;
            FirstMinute = now.Minute;
            FirstSecond = now.Second;

            while (true)
            {
                if (resetTime)
                {
                    
                    hour = 0;
                    minutes = 0;
                    seconds = 0;
                    for (long i = 0; restartTime != true; i++)
                    {
                        i = 0;
                        Console.WriteLine("Pause");
                        Thread.Sleep(1000);
                    }

                    resetTime = false;
                }

                labelTimer.Text = ("Timer "+hour + ":" + minutes + ":" + seconds);
                if (seconds == 60)
                {
                    seconds = 0;
                    minutes++;
                }

                if (minutes == 60)
                {
                    seconds = 0;
                    hour++;
                }

                Console.WriteLine("start run");
                seconds++;
                Thread.Sleep(995);
            }
        }


        private void SetParamertsComponent()
        {
            this.Text=("Timer");
            //this.Icon=new Icon("neco.ico");
            _started.Size = new Size(40, 20);
            _stoped.Size = new Size(40, 20);
            labelTime.Size = new Size(1000, 40);
            labelTimer.Size = new Size(1000, 40);

            labelTime.Font = new Font("Arial", 24);
            labelTimer.Font = new Font("Arial", 24);

            _started.Text = "start";
            _stoped.Text = "stop";

            labelTime.Location = new Point(0, 0);
            labelTimer.Location = new Point(0, 45);
            _started.Location = new Point(30, 130);
            _stoped.Location = new Point(30, 100);
        }

        private void AddingComponents()
        {
            this.Controls.Add(labelTime);
            this.Controls.Add(labelTimer);
            this.Controls.Add(_started);
            this.Controls.Add(_stoped);
        }

        public static void FormWriter()
        {
            while (true)
            {
                DateTime now = DateTime.Now;

                labelTime.Text = ("Time " + now.Hour + ":" + now.Minute + ":" + now.Second);
                Thread.Sleep(995);
            }
        }

        public static void ConsoleWrite()
        {
            Console.CursorVisible = false;
            while (true)
            {
                DateTime now1 = DateTime.Now;
                Console.Clear();
                Console.WriteLine(now1.ToFileTimeUtc());
                Console.WriteLine("actual time " + now1.Hour + ":" + now1.Minute + ":" + now1.Second);
                Console.WriteLine(DateTime.Now.ToString("ss"));
                Console.ReadKey();
                Thread.Sleep(995);
            }
        }
    }
}