﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Windows.Forms.VisualStyles;
using NAudio.Wave;

namespace arsPlayer
{
    internal class Program
    {

        public static void Main(string[] args)
        {
            string SongPath = "d:/SONG5.ARS";
            if (args.Length > 0)
            {
                Console.WriteLine(args[0]);
                SongPath = args[0];
            }


            int delay = 100;

            List<int> Frequncyes = new List<int>();
            string cmd = "a";
            bool loadingPdata = false;
            bool loadingASdata = false;
            bool loadingFdata = false;

            int f;
            int numberOfThones;

            using (StreamReader sr = new StreamReader(SongPath))
            {
                while ((cmd = sr.ReadLine()) != "##end")
                {
                    if (cmd == "#Pdata")
                    {
                        loadingASdata = false;
                        loadingFdata = false;
                        loadingPdata = true;
                        goto point;
                    }

                    if (cmd == "#ASdata")
                    {
                        loadingFdata = false;
                        loadingPdata = false;
                        loadingASdata = true;
                        goto point;
                    }

                    if (cmd == "#Fdata")
                    {
                        loadingPdata = false;
                        loadingASdata = false;
                        loadingFdata = true;
                        goto point;
                    }

                    if (loadingPdata)
                    {
                        delay = Convert.ToInt32(cmd);
                    }
                    else if (loadingASdata)
                    {
                        //numberOfThones = Convert.ToInt32(cmd);
                    }
                    else if (loadingFdata)
                    {
                        f = Convert.ToInt32(cmd);

                        Frequncyes.Add(f);
                    }

                    point: ;
                }

                sr.Close();
            }

            int fr;
            int n=1;
            string extension = ".wav";
            string name = "";
            SongPath = "d:/SONG.wav";
            if (args.Length > 0)
            {
                Console.WriteLine(args[0]);
                SongPath = args[0];
            }
            back:
            name = SongPath;
            string tempFile = (name+Convert.ToString(n)+extension);
            if (File.Exists(tempFile))
            {
                n++;
                goto back;
            }
            
            WaveFormat waveFormat = new WaveFormat(8000, 16, 1);
            WaveFileWriter waveFileWriter = new WaveFileWriter(tempFile, waveFormat);
            for (int i = 0; i < Frequncyes.Count; i++)
            {
                if (Frequncyes[i] > 37)
                {
                    fr = Frequncyes[i];
                    playTone(fr, waveFileWriter);
                }
                else
                {
                    playTone(0, waveFileWriter);
                }
            }

            waveFileWriter.Flush();
            waveFileWriter.Close();
        }

        static void playTone(float frequency, WaveFileWriter waveFileWriter)
        {
            float amplitude = 0.66f;

            for (float n = 0; n < waveFileWriter.WaveFormat.SampleRate; n = n + 10)
            {
                float sample = (float) (amplitude * Math.Sin((2 * Math.PI * n * frequency) / waveFileWriter.WaveFormat.SampleRate));
                waveFileWriter.WriteSample(sample);
            }
        }
    }
}